const { CognitoIdentityServiceProvider } = require('aws-sdk');

const cognitoIdentityServiceProvider = new CognitoIdentityServiceProvider();

exports.handler = async (event) => {
  const { token } = event;
  
  try {
    const params = {
      UserPoolId: process.env.USER_POOL_ID,
      ClientId: process.env.CLIENT_ID,
      AccessToken: token
    };
    
    const userData = await cognitoIdentityServiceProvider.getUser(params).promise();
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'User authenticated successfully',
        userData
      })
    };
  } catch (err) {
    return {
      statusCode: 401,
      body: JSON.stringify({
        message: 'Authentication failed',
        error: err.message
      })
    };
  }
};
